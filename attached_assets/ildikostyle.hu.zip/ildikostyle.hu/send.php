<?php
	$headers = "From: ildikostyle.hu" .base64_encode($from[0])."<". $from[1] . "\n";

	$headers .=
    "Content-Type: text/html; "
    . "charset=UTF-8; format=flowed\n"
    . "MIME-Version: 1.0\n"
    . "Content-Transfer-Encoding: 8bit\n"
    . "X-Mailer: PHP\n";
  $name = $_POST["name"];
  $mail = $_POST["mail"];
  $message = $_POST["message"];
  
  $return=mail("jonatan5@t-online.hu","Lev�l", "N�v:".$name."\nEmail: ".$mail."\n�zenet: ".$message."\n", $headers);

?>

